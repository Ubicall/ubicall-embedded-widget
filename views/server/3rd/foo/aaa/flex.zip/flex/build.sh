#!/bin/sh
mxmlc -static-link-runtime-shared-libraries freeswitch.mxml
